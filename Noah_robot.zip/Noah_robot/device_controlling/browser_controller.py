"""
Noah Browser Controller
=======================

Controls Chromium from Noah.

Location:
    device_controlling/browser_controller.py

Works on:
    - Windows development PC
    - Raspberry Pi / Raspberry Pi OS

Main functions:
    open_browser()
    open_url()
    close_browser()
    is_running()
    get_status()
"""

import os
import platform
import shutil
import subprocess
import time
import webbrowser
from urllib.parse import urlparse


class NoahBrowser:
    """Controls the Chromium browser for Noah."""

    def __init__(self):
        self.process = None
        self.browser_path = None
        self.current_url = None
        self.kiosk_mode = False

        self.system = platform.system().lower()

        self._find_browser()

    # ---------------------------------------------------------
    # FIND BROWSER
    # ---------------------------------------------------------

    def _find_browser(self):
        """Find Chromium/Chrome executable."""

        possible_commands = []

        if self.system == "windows":
            possible_commands = [
                "chromium",
                "chrome",
            ]

            possible_paths = [
                os.path.expandvars(
                    r"%PROGRAMFILES%\Chromium\Application\chrome.exe"
                ),
                os.path.expandvars(
                    r"%PROGRAMFILES%\Google\Chrome\Application\chrome.exe"
                ),
                os.path.expandvars(
                    r"%LOCALAPPDATA%\Chromium\Application\chrome.exe"
                ),
                os.path.expandvars(
                    r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
                ),
            ]

        else:
            # Linux / Raspberry Pi
            possible_commands = [
                "chromium",
                "chromium-browser",
                "google-chrome",
            ]

            possible_paths = [
                "/usr/bin/chromium",
                "/usr/bin/chromium-browser",
                "/usr/bin/google-chrome",
            ]

        # Check PATH first
        for command in possible_commands:
            found = shutil.which(command)

            if found:
                self.browser_path = found
                return

        # Check common installation paths
        for path in possible_paths:
            if os.path.exists(path):
                self.browser_path = path
                return

    # ---------------------------------------------------------
    # URL VALIDATION
    # ---------------------------------------------------------

    def _is_valid_url(self, url):
        """Check whether a URL is safe enough to open."""

        if not isinstance(url, str):
            return False

        url = url.strip()

        if not url:
            return False

        # Allow normal HTTP/HTTPS websites only.
        parsed = urlparse(url)

        if parsed.scheme not in ("http", "https"):
            return False

        if not parsed.netloc:
            return False

        return True

    def _prepare_url(self, url):
        """Convert simple website names into URLs."""

        if not isinstance(url, str):
            return None

        url = url.strip()

        if not url:
            return None

        # Already a complete URL
        if url.startswith("http://") or url.startswith("https://"):
            return url

        # Localhost
        if url.startswith("localhost"):
            return "http://" + url

        # IP address / local network address
        if url.startswith("127.0.0.1"):
            return "http://" + url

        # Simple domain
        if "." in url:
            return "https://" + url

        # If it isn't a domain, use a search.
        search_url = (
            "https://www.google.com/search?q="
            + url.replace(" ", "+")
        )

        return search_url

    # ---------------------------------------------------------
    # STATUS
    # ---------------------------------------------------------

    def is_running(self):
        """Return True if Noah currently owns a browser process."""

        if self.process is not None:

            if self.process.poll() is None:
                return True

            self.process = None

        return False

    # ---------------------------------------------------------
    # OPEN BROWSER
    # ---------------------------------------------------------

    def open_browser(self, url=None, kiosk=False):
        """
        Open Chromium.

        Example:
            browser.open_browser()

        Or:
            browser.open_browser("https://example.com")
        """

        self.kiosk_mode = kiosk

        if url is None:
            url = "https://www.google.com"

        prepared_url = self._prepare_url(url)

        if prepared_url is None:
            print("Browser: invalid URL.")
            return False

        # If Chromium executable was found
        if self.browser_path:

            try:
                command = [
                    self.browser_path,
                    "--no-first-run",
                    "--no-default-browser-check",
                ]

                if kiosk:
                    command.append("--kiosk")
                else:
                    command.append("--start-maximized")

                command.append(prepared_url)

                self.process = subprocess.Popen(
                    command,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )

                self.current_url = prepared_url

                time.sleep(1)

                print("Browser: opened")
                print("URL:", prepared_url)

                return True

            except Exception as error:
                print("Browser: launch error:", error)
                return False

        # Fallback for development computer
        try:
            webbrowser.open(prepared_url)

            self.current_url = prepared_url

            print("Browser: opened using system browser.")

            return True

        except Exception as error:
            print("Browser: error:", error)
            return False

    # ---------------------------------------------------------
    # OPEN URL
    # ---------------------------------------------------------

    def open_url(self, url):
        """Open a specific website."""

        prepared_url = self._prepare_url(url)

        if prepared_url is None:
            print("Browser: invalid URL.")
            return False

        # If Noah's Chromium process is alive,
        # open the URL in the existing browser.
        if self.is_running():

            try:
                subprocess.Popen(
                    [
                        self.browser_path,
                        prepared_url,
                    ],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )

                self.current_url = prepared_url

                print("Browser: navigating to", prepared_url)

                return True

            except Exception as error:
                print("Browser: navigation error:", error)

                return False

        # Browser isn't open, so launch it.
        return self.open_browser(prepared_url, self.kiosk_mode)

    # ---------------------------------------------------------
    # HOME
    # ---------------------------------------------------------

    def home(self):
        """Open Noah's browser home page."""

        return self.open_url("https://www.google.com")

    # ---------------------------------------------------------
    # SEARCH
    # ---------------------------------------------------------

    def search(self, query):
        """Search the web."""

        if not isinstance(query, str):
            return False

        query = query.strip()

        if not query:
            return False

        search_url = (
            "https://www.google.com/search?q="
            + query.replace(" ", "+")
        )

        return self.open_url(search_url)

    # ---------------------------------------------------------
    # CLOSE
    # ---------------------------------------------------------

    def close_browser(self):
        """Close the browser process controlled by Noah."""

        if self.process is None:
            print("Browser: not running.")
            return True

        try:

            if self.process.poll() is None:
                self.process.terminate()

                try:
                    self.process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self.process.kill()

            self.process = None
            self.current_url = None

            print("Browser: closed.")

            return True

        except Exception as error:
            print("Browser: close error:", error)

            return False

    # ---------------------------------------------------------
    # KIOSK MODE
    # ---------------------------------------------------------

    def set_kiosk_mode(self, enabled=True):
        """
        Set kiosk mode for the next browser launch.

        Kiosk mode removes normal browser controls and is
        useful when Noah's screen should behave like a
        dedicated computer interface.
        """

        self.kiosk_mode = bool(enabled)

        print(
            "Browser kiosk mode:",
            "ON" if self.kiosk_mode else "OFF"
        )

    # ---------------------------------------------------------
    # RESTART
    # ---------------------------------------------------------

    def restart(self, url=None):
        """Close and reopen the browser."""

        self.close_browser()

        time.sleep(0.5)

        return self.open_browser(
            url=url,
            kiosk=self.kiosk_mode
        )

    # ---------------------------------------------------------
    # STATUS
    # ---------------------------------------------------------

    def get_status(self):
        """Return browser status."""

        return {
            "available": self.browser_path is not None,
            "browser_path": self.browser_path,
            "running": self.is_running(),
            "current_url": self.current_url,
            "kiosk_mode": self.kiosk_mode,
            "system": self.system,
        }

    # ---------------------------------------------------------
    # SHUTDOWN
    # ---------------------------------------------------------

    def close(self):
        """Clean shutdown."""

        self.close_browser()


# =============================================================
# DIRECT TEST
# =============================================================

if __name__ == "__main__":

    print("=" * 40)
    print("NOAH BROWSER CONTROLLER TEST")
    print("=" * 40)

    browser = NoahBrowser()

    print("\nBrowser status:")
    print(browser.get_status())

    print("\nOpening browser...")

    browser.open_browser(
        "https://www.google.com",
        kiosk=False
    )

    time.sleep(5)

    print("\nFinal status:")
    print(browser.get_status())

    print("\nClosing browser...")

    browser.close_browser()

    print("\nTest complete.")
