class NoahSafety:
    """
    Noah's safety system.

    Handles:
    - Emergency stop
    - Movement permission
    - Safety status
    - Critical-condition checks
    """

    def __init__(self):
        self.safe = True
        self.emergency_stop = False
        self.last_reason = None

        print("Safety: initialized")
        print("Safety: system SAFE")

    # -------------------------
    # Emergency Stop
    # -------------------------

    def emergency_stop_now(self, reason="Emergency stop activated"):
        """
        Immediately put Noah into a stopped safety state.
        """

        self.emergency_stop = True
        self.safe = False
        self.last_reason = reason

        print("\n!!! SAFETY STOP !!!")
        print(f"Reason: {reason}")

    def reset_emergency_stop(self):
        """
        Reset the emergency stop after the situation is safe.
        """

        self.emergency_stop = False
        self.safe = True
        self.last_reason = None

        print("Safety: emergency stop reset")
        print("Safety: system SAFE")

    # -------------------------
    # Movement Safety
    # -------------------------

    def can_move(self):
        """
        Returns True if Noah is allowed to move.
        """

        if self.emergency_stop:
            return False

        if not self.safe:
            return False

        return True

    def allow_movement(self):
        """
        Explicitly check whether movement is allowed.
        """

        if self.can_move():
            print("Safety: movement allowed")
            return True

        print("Safety: movement BLOCKED")

        if self.last_reason:
            print(f"Reason: {self.last_reason}")

        return False

    # -------------------------
    # Safety State
    # -------------------------

    def set_unsafe(self, reason):
        """
        Put Noah into an unsafe state.
        """

        self.safe = False
        self.last_reason = reason

        print(f"Safety: UNSAFE")
        print(f"Reason: {reason}")

    def set_safe(self):
        """
        Mark the system as safe.
        """

        if self.emergency_stop:
            print("Safety: cannot become SAFE while emergency stop is active")
            return False

        self.safe = True
        self.last_reason = None

        print("Safety: SAFE")
        return True

    # -------------------------
    # Status
    # -------------------------

    def get_status(self):
        """
        Return the current safety state.
        """

        return {
            "safe": self.safe,
            "emergency_stop": self.emergency_stop,
            "can_move": self.can_move(),
            "reason": self.last_reason
        }

    # -------------------------
    # Shutdown
    # -------------------------

    def shutdown(self):
        """
        Put Noah into a safe state before shutdown.
        """

        self.emergency_stop_now("Robot shutting down")
        print("Safety: shutdown protection active")


# -------------------------
# Test
# -------------------------

if __name__ == "__main__":

    print("\n==============================")
    print("       NOAH SAFETY TEST")
    print("==============================\n")

    safety = NoahSafety()

    print("\nInitial status:")
    print(safety.get_status())

    print("\nTesting movement:")
    safety.allow_movement()

    print("\nTesting emergency stop:")
    safety.emergency_stop_now("Test emergency stop")

    print("\nTrying movement after emergency stop:")
    safety.allow_movement()

    print("\nResetting emergency stop:")
    safety.reset_emergency_stop()

    print("\nTrying movement again:")
    safety.allow_movement()

    print("\nFinal status:")
    print(safety.get_status())

    print("\nSafety test complete.")