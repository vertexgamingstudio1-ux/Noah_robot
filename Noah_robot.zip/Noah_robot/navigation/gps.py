import math
import time

try:
    import serial
except ImportError:
    serial = None

try:
    import pynmea2
except ImportError:
    pynmea2 = None


class NoahGPS:
    """
    Noah GPS navigation system.

    Reads NMEA GPS data from a serial GPS module and provides:
    - latitude
    - longitude
    - altitude
    - GPS fix status
    - satellite count
    - distance calculations
    - bearing calculations
    """

    DEFAULT_PORT = "/dev/serial0"
    DEFAULT_BAUDRATE = 9600

    EARTH_RADIUS = 6371000  # meters

    def __init__(
        self,
        port=DEFAULT_PORT,
        baudrate=DEFAULT_BAUDRATE,
        timeout=1
    ):
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout

        self.serial = None

        self.latitude = None
        self.longitude = None
        self.altitude = None
        self.satellites = None

        self.fix_available = False
        self.last_update = None

        print("GPS: initializing...")

    # --------------------------------------------------
    # Connection
    # --------------------------------------------------

    def connect(self):
        """
        Open the serial connection to the GPS.
        """

        if serial is None:
            raise ImportError(
                "pyserial is not installed. "
                "Install it with: pip install pyserial"
            )

        if self.serial is not None:
            return

        print(f"GPS: connecting to {self.port}...")

        self.serial = serial.Serial(
            port=self.port,
            baudrate=self.baudrate,
            timeout=self.timeout
        )

        print("GPS: serial connection ready")

    def close(self):
        """
        Close the GPS serial connection.
        """

        if self.serial is not None:
            self.serial.close()
            self.serial = None

        print("GPS: closed")

    # --------------------------------------------------
    # GPS Data
    # --------------------------------------------------

    def read(self):
        """
        Read GPS data until a useful GPS sentence is received.

        Returns:
            True  -> valid location received
            False -> no valid location yet
        """

        if self.serial is None:
            self.connect()

        if pynmea2 is None:
            raise ImportError(
                "pynmea2 is not installed. "
                "Install it with: pip install pynmea2"
            )

        try:
            line = self.serial.readline().decode(
                "ascii",
                errors="ignore"
            ).strip()

            if not line:
                return False

            try:
                message = pynmea2.parse(line)
            except pynmea2.ParseError:
                return False

            # ------------------------------------------
            # Position
            # ------------------------------------------

            if hasattr(message, "latitude"):
                if message.latitude and message.longitude:

                    self.latitude = float(message.latitude)
                    self.longitude = float(message.longitude)

                    self.fix_available = True
                    self.last_update = time.time()

            # ------------------------------------------
            # Altitude
            # ------------------------------------------

            if hasattr(message, "altitude"):
                if message.altitude:
                    self.altitude = float(message.altitude)

            # ------------------------------------------
            # Satellites
            # ------------------------------------------

            if hasattr(message, "num_sats"):
                if message.num_sats:
                    try:
                        self.satellites = int(message.num_sats)
                    except (ValueError, TypeError):
                        pass

            return self.fix_available

        except (serial.SerialException, OSError) as error:
            print(f"GPS: serial error: {error}")
            return False

    # --------------------------------------------------
    # Wait For Fix
    # --------------------------------------------------

    def wait_for_fix(self, timeout=60):
        """
        Wait until GPS obtains a valid position.

        Returns:
            True if a fix is obtained.
            False if timeout expires.
        """

        print("GPS: waiting for satellite fix...")

        start_time = time.time()

        while time.time() - start_time < timeout:

            if self.read():
                print("GPS: fix acquired")
                return True

            time.sleep(0.1)

        print("GPS: fix timeout")
        return False

    # --------------------------------------------------
    # Current Location
    # --------------------------------------------------

    def get_location(self):
        """
        Return Noah's current GPS position.
        """

        if not self.fix_available:
            return None

        return {
            "latitude": self.latitude,
            "longitude": self.longitude,
            "altitude": self.altitude,
            "satellites": self.satellites
        }

    def has_fix(self):
        """
        Check whether Noah currently has a GPS fix.
        """

        return self.fix_available

    # --------------------------------------------------
    # Distance
    # --------------------------------------------------

    def distance_to(self, latitude, longitude):
        """
        Calculate distance from Noah to a destination.

        Returns distance in meters.
        """

        if not self.fix_available:
            return None

        lat1 = math.radians(self.latitude)
        lon1 = math.radians(self.longitude)

        lat2 = math.radians(float(latitude))
        lon2 = math.radians(float(longitude))

        dlat = lat2 - lat1
        dlon = lon2 - lon1

        a = (
            math.sin(dlat / 2) ** 2
            +
            math.cos(lat1)
            * math.cos(lat2)
            * math.sin(dlon / 2) ** 2
        )

        c = 2 * math.atan2(
            math.sqrt(a),
            math.sqrt(1 - a)
        )

        return self.EARTH_RADIUS * c

    # --------------------------------------------------
    # Bearing
    # --------------------------------------------------

    def bearing_to(self, latitude, longitude):
        """
        Calculate bearing from Noah to a destination.

        0   = North
        90  = East
        180 = South
        270 = West
        """

        if not self.fix_available:
            return None

        lat1 = math.radians(self.latitude)
        lat2 = math.radians(float(latitude))

        dlon = math.radians(
            float(longitude) - self.longitude
        )

        x = math.sin(dlon) * math.cos(lat2)

        y = (
            math.cos(lat1) * math.sin(lat2)
            -
            math.sin(lat1)
            * math.cos(lat2)
            * math.cos(dlon)
        )

        bearing = math.degrees(
            math.atan2(x, y)
        )

        return (bearing + 360) % 360

    # --------------------------------------------------
    # Direction
    # --------------------------------------------------

    def direction_to(self, latitude, longitude):
        """
        Convert bearing into a simple compass direction.
        """

        bearing = self.bearing_to(
            latitude,
            longitude
        )

        if bearing is None:
            return None

        directions = [
            "North",
            "North-East",
            "East",
            "South-East",
            "South",
            "South-West",
            "West",
            "North-West"
        ]

        index = int((bearing + 22.5) // 45) % 8

        return directions[index]

    # --------------------------------------------------
    # Status
    # --------------------------------------------------

    def get_status(self):
        """
        Return the current GPS system status.
        """

        return {
            "connected": self.serial is not None,
            "fix_available": self.fix_available,
            "latitude": self.latitude,
            "longitude": self.longitude,
            "altitude": self.altitude,
            "satellites": self.satellites,
            "last_update": self.last_update
        }


# ======================================================
# TEST
# ======================================================

if __name__ == "__main__":

    print("\n==============================")
    print("        NOAH GPS TEST")
    print("==============================\n")

    gps = NoahGPS()

    try:
        gps.connect()

        print("\nWaiting for GPS data...\n")

        if gps.wait_for_fix(timeout=30):

            print("\nGPS LOCATION:")
            print(gps.get_location())

            print("\nGPS STATUS:")
            print(gps.get_status())

        else:
            print("\nNo GPS fix received.")

    except Exception as error:

        print("\nGPS ERROR:")
        print(error)

    finally:

        gps.close()

    print("\nGPS test complete.")