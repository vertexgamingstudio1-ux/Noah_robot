import time

from audio.microphone import NoahMicrophone
from audio.speech_recognition import NoahSpeechRecognizer
from audio.speaker import NoahSpeaker

from core.ai_brain import NoahBrain
from display.face import NoahFace

from hardware.motors import NoahMotors
from safety.safety import NoahSafety



class Noah:
    """
    Main controller for Noah.

    main.py is the central controller.
    Other modules perform their specific jobs.
    """

    def __init__(self):
        print("\n==============================")
        print("       NOAH ROBOT")
        print("==============================\n")

        self.mic = None
        self.recognizer = None
        self.speaker = None
        self.brain = None
        self.face = None
        self.motors = None
        self.safety = None

        self.running = False

    # -------------------------------------------------
    # INITIALIZATION
    # -------------------------------------------------

    def initialize(self):
        print("Noah: initializing systems...\n")

        try:
            # Face
            print("Initializing face...")
            self.face = NoahFace()
            self.face.set_state("idle")

            # Microphone
            print("Initializing microphone...")
            self.mic = NoahMicrophone()

            # Speech recognition
            print("Initializing speech recognition...")
            self.recognizer = NoahSpeechRecognizer()

            # Speaker
            print("Initializing speaker...")
            self.speaker = NoahSpeaker()

            # AI brain
            print("Initializing AI brain...")
            self.brain = NoahBrain()

            # Motors
            print("Initializing motors...")
            self.motors = NoahMotors()

            # Safety
            print("Initializing safety system...")
            self.safety = NoahSafety()

            print("\nNoah: all systems initialized.")
            print("Noah: ready.\n")

            self.running = True
            return True

        except Exception as error:
            print("\nNoah initialization error:")
            print(error)

            self.shutdown()
            return False

    # -------------------------------------------------
    # COMMAND HANDLER
    # -------------------------------------------------

    def handle_command(self, text):
        """
        Decide what Noah should do with recognized speech.
        """

        if not text:
            return

        command = text.lower().strip()

        print(f"\nNoah received: {text}")

        # -------------------------
        # EMERGENCY / STOP
        # -------------------------

        if (
            command == "stop"
            or "emergency stop" in command
            or command == "halt"
        ):
            self.stop_robot()
            return

        # -------------------------
        # MOVEMENT
        # -------------------------

        if "move forward" in command or command == "forward":
            self.move_robot("forward")
            return

        if "move backward" in command or command == "backward":
            self.move_robot("backward")
            return

        if "turn left" in command or command == "left":
            self.move_robot("left")
            return

        if "turn right" in command or command == "right":
            self.move_robot("right")
            return

        # -------------------------
        # EVERYTHING ELSE → AI
        # -------------------------

        self.talk_to_brain(text)

    # -------------------------------------------------
    # MOVEMENT
    # -------------------------------------------------

    def move_robot(self, direction):
        """
        Move Noah only if the safety system allows it.
        """

        if self.motors is None:
            print("Noah: motors are not initialized.")
            return

        if self.safety is None:
            print("Noah: safety system is not initialized.")
            return

        if not self.safety.can_move():
            print("Noah: movement blocked by safety system.")
            self.stop_robot()
            return

        print(f"Noah: moving {direction}")

        try:
            if self.face:
                self.face.set_state("alert")

            if direction == "forward":
                self.motors.forward()

            elif direction == "backward":
                self.motors.backward()

            elif direction == "left":
                self.motors.left()

            elif direction == "right":
                self.motors.right()

            else:
                print(f"Noah: unknown movement: {direction}")
                self.stop_robot()

        except Exception as error:
            print("Noah movement error:")
            print(error)
            self.stop_robot()

    # -------------------------------------------------
    # STOP
    # -------------------------------------------------

    def stop_robot(self):
        """
        Immediately stop the motors.
        """

        print("Noah: stopping.")

        try:
            if self.motors:
                self.motors.stop()

            if self.face:
                self.face.set_state("idle")

        except Exception as error:
            print("Noah stop error:")
            print(error)

    # -------------------------------------------------
    # AI
    # -------------------------------------------------

    def talk_to_brain(self, text):
        """
        Send dynamically recognized speech to Noah's AI brain.
        """

        if not self.brain:
            print("Noah: AI brain is not initialized.")
            return

        if not text:
            return

        try:
            if self.face:
                self.face.set_state("thinking")

            # IMPORTANT:
            # This is dynamic speech input.
            response = self.brain.ask(text)

            if not response:
                print("Noah: brain returned no response.")
                return

            print(f"\nNoah: {response}")

            if self.face:
                self.face.set_state("speaking")

            if self.speaker:
                self.speaker.speak(response)

            if self.face:
                self.face.set_state("idle")

        except Exception as error:
            print("Noah AI error:")
            print(error)

            if self.face:
                self.face.set_state("error")

            if self.speaker:
                try:
                    self.speaker.speak(
                        "Sorry, something went wrong."
                    )
                except Exception:
                    pass

            if self.face:
                self.face.set_state("idle")

    # -------------------------------------------------
    # LISTEN
    # -------------------------------------------------

    def listen(self):
        """
        Listen once and return recognized speech.
        """

        if not self.recognizer:
            print("Noah: speech recognizer is not initialized.")
            return ""

        try:
            if self.face:
                self.face.set_state("listening")

            text = self.recognizer.recognize_once(
                duration=5
            )

            if self.face:
                self.face.set_state("idle")

            return text

        except Exception as error:
            print("Noah listening error:")
            print(error)

            if self.face:
                self.face.set_state("error")

            return ""

    # -------------------------------------------------
    # MAIN LOOP
    # -------------------------------------------------

    def run(self):
        """
        Main Noah loop.

        Microphone
            ↓
        Speech recognition
            ↓
        main.py
            ↓
        Command OR AI
            ↓
        Action / Speaker
        """

        if not self.initialize():
            print("Noah: startup failed.")
            return

        print("==============================")
        print("       NOAH IS READY")
        print("==============================")
        print("Speak to Noah.")
        print("Press Ctrl+C to stop.\n")

        try:
            while self.running:

                # Listen to the user
                text = self.listen()

                # Nothing recognized
                if not text:
                    continue

                # Main controller decides what to do
                self.handle_command(text)

                # Small pause before listening again
                time.sleep(0.2)

        except KeyboardInterrupt:
            print("\nNoah: shutdown requested.")

        except Exception as error:
            print("\nNoah main loop error:")
            print(error)

        finally:
            self.shutdown()

    # -------------------------------------------------
    # SHUTDOWN
    # -------------------------------------------------

    def shutdown(self):
        """
        Safely shut down every subsystem.
        """

        print("\nNoah: shutting down...")

        self.running = False

        # Stop motors FIRST
        try:
            if self.motors:
                self.motors.stop()
                self.motors.close()
        except Exception as error:
            print("Motor shutdown error:", error)

        # Microphone
        try:
            if self.mic:
                self.mic.close()
        except Exception as error:
            print("Microphone shutdown error:", error)

        # Speaker
        try:
            if self.speaker:
                self.speaker.close()
        except Exception as error:
            print("Speaker shutdown error:", error)

        # Safety
        try:
            if self.safety:
                self.safety.shutdown()
        except Exception as error:
            print("Safety shutdown error:", error)

        print("Noah: shutdown complete.")


# =====================================================
# PROGRAM START
# =====================================================

if __name__ == "__main__":
    noah = Noah()
    noah.run()