import requests


class NoahBrain:
    """
    Noah's AI brain.

    Receives dynamic text from main.py and sends it
    to OpenRouter's Free Models Router.
    """

    API_URL = "https://openrouter.ai/api/v1/chat/completions"
    MODEL = "openrouter/free"

    # Put your OpenRouter API key here locally.
    # DO NOT share the real key publicly.
    API_KEY = "sk-or-v1-0ba02ab27de9fe2f59321c464029771b6276a762f1884bc9143d4d7d3e9224a"

    SYSTEM_PROMPT = """
You are Noah, a friendly AI robot assistant.

Your responses should be:

- Natural and conversational
- Clear and reasonably short
- Helpful
- Suitable for a robot speaking aloud
- Avoid unnecessary formatting
- Do not describe your internal reasoning

You are running inside a physical robot called Noah.
"""

    def __init__(self):
        self.api_key = self.API_KEY

        if (
            not self.api_key
            or self.api_key == "PASTE_YOUR_OPENROUTER_API_KEY_HERE"
        ):
            raise ValueError(
                "OpenRouter API key is missing. "
                "Add your API key to NoahBrain.API_KEY."
            )

        self.messages = [
            {
                "role": "system",
                "content": self.SYSTEM_PROMPT
            }
        ]

        self.last_model = None

        print("Noah Brain: initialized")
        print("Noah Brain: model = openrouter/free")

    def ask(self, text):
        """
        Send any user text to Noah's AI brain.

        Example:
            brain.ask("What is photosynthesis?")
            brain.ask("Help me make a study timetable.")
            brain.ask("Tell me a joke.")
        """

        if not text or not text.strip():
            return ""

        text = text.strip()

        user_message = {
            "role": "user",
            "content": text
        }

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

        payload = {
            "model": self.MODEL,
            "messages": self.messages + [user_message],
            "stream": False
        }

        print(f"\nYou: {text}")
        print("Noah Brain: thinking...")

        try:
            response = requests.post(
                self.API_URL,
                headers=headers,
                json=payload,
                timeout=(10, 30)
            )

            print(f"Noah Brain: HTTP {response.status_code}")

            response.raise_for_status()

            data = response.json()

            self.last_model = data.get("model")

            answer = (
                data["choices"][0]["message"]["content"]
                .strip()
            )

            # Save conversation
            self.messages.append(user_message)

            self.messages.append({
                "role": "assistant",
                "content": answer
            })

            print(f"Noah Brain: model used = {self.last_model}")
            print(f"Noah: {answer}")

            return answer

        except requests.exceptions.Timeout:
            print("Noah Brain: request timed out")
            return "Sorry, my brain took too long to respond."

        except requests.exceptions.RequestException as error:
            print("Noah Brain: network/API error")
            print(error)

            return "Sorry, I cannot connect to my brain right now."

        except (KeyError, IndexError, TypeError, ValueError) as error:
            print("Noah Brain: invalid API response")
            print(error)

            try:
                print("Response received:")
                print(response.text[:2000])
            except Exception:
                pass

            return "Sorry, I received an invalid response."

    def clear_memory(self):
        """Clear the current conversation."""

        self.messages = [
            {
                "role": "system",
                "content": self.SYSTEM_PROMPT
            }
        ]

        print("Noah Brain: conversation cleared")

    def get_last_model(self):
        """Return the model selected by OpenRouter."""

        return self.last_model


if __name__ == "__main__":
    print("\nStarting Noah Brain interactive test...\n")

    brain = NoahBrain()

    print("Type something for Noah.")
    print("Type 'exit' to stop.\n")

    while True:
        user_text = input("You: ").strip()

        if user_text.lower() == "exit":
            break

        if not user_text:
            continue

        response = brain.ask(user_text)

        print(f"\nNoah: {response}\n")

    print("Noah Brain test finished.")

