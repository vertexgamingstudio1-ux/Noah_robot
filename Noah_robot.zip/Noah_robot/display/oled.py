# display/oled.py

class NoahDisplay:
    """
    Hardware display layer for Noah.

    face.py should NOT need to know how the TFT works.
    """

    WIDTH = 240
    HEIGHT = 320

    def __init__(self):
        self.initialized = False
        self._initialize()

    def _initialize(self):
        """
        Initialize the TFT hardware.

        Hardware-specific ILI9338 code will go here.
        """
        print("Noah display: initializing ILI9338 TFT...")

        # Hardware initialization will be added here.
        #
        # IMPORTANT:
        # Do not put face/animation code in this file.

        self.initialized = True
        print("Noah display: ready")

    def clear(self):
        """Clear the entire display."""
        if not self.initialized:
            return

        print("Noah display: clear")

    def show(self, image):
        """
        Display a Pillow image.

        face.py will eventually call this.
        """
        if not self.initialized:
            return

        if image is None:
            return

        # TFT image output will be implemented here.
        pass

    def fill(self, color):
        """Fill the entire screen with a color."""
        if not self.initialized:
            return

        # TFT fill implementation will go here.
        pass

    def close(self):
        """Release display resources."""
        if not self.initialized:
            return

        print("Noah display: closing...")
        self.initialized = False