# display/touch.py

"""
Noah Touchscreen Controller
===========================

Hardware:
    TF028 2.8" TFT
    ILI9341 display
    4-wire resistive touchscreen

Important:
    The original TF028 is an Arduino-style shield.
    Its documented touch lines are:

        XP = Arduino D8
        XM = Arduino A2
        YP = Arduino A3
        YM = Arduino D9

    These are NOT Raspberry Pi GPIO numbers.

This module keeps the touch logic independent from the rest of Noah.
Once the physical Pi wiring/interface is finalized, only the low-level
hardware section needs to be connected.

Public API:
    touch.is_ready()
    touch.is_pressed()
    touch.get_touch()
    touch.wait_for_touch()
    touch.get_position()
    touch.set_calibration()
    touch.calibrate()
    touch.map_to_screen()
    touch.is_inside()
    touch.close()

Returned touch position:

    {
        "x": 0,
        "y": 0,
        "pressure": 0
    }

or None when there is no touch.
"""

import time


# ============================================================
# SCREEN SETTINGS
# ============================================================

SCREEN_WIDTH = 320
SCREEN_HEIGHT = 240

# Resistive touchscreen pressure limits.
MIN_PRESSURE = 10
MAX_PRESSURE = 1000


# ============================================================
# DEFAULT CALIBRATION
# ============================================================

# These are common TF028 example calibration values.
#
# IMPORTANT:
# Real hardware calibration should replace these values.
# Do not assume they are perfect for every individual panel.

DEFAULT_TS_MIN_X = 100
DEFAULT_TS_MAX_X = 920
DEFAULT_TS_MIN_Y = 70
DEFAULT_TS_MAX_Y = 900


class NoahTouch:
    """
    Main touchscreen controller for Noah.
    """

    def __init__(
        self,
        screen_width=SCREEN_WIDTH,
        screen_height=SCREEN_HEIGHT,
    ):
        self.screen_width = screen_width
        self.screen_height = screen_height

        self.ts_min_x = DEFAULT_TS_MIN_X
        self.ts_max_x = DEFAULT_TS_MAX_X
        self.ts_min_y = DEFAULT_TS_MIN_Y
        self.ts_max_y = DEFAULT_TS_MAX_Y

        self.rotation = 0
        self.ready = False
        self.closed = False

        self.last_position = None
        self.last_touch_time = 0

        print("Touchscreen: initializing...")

        self._initialize_hardware()

    # ========================================================
    # HARDWARE INITIALIZATION
    # ========================================================

    def _initialize_hardware(self):
        """
        Initialize the physical touch hardware.

        The TF028 is not a normal Raspberry Pi SPI touchscreen.
        Its resistive touch panel uses the shield's shared pins.

        Therefore the Pi-specific low-level implementation belongs
        here once the exact Pi wiring/interface is finalized.
        """

        # Hardware driver intentionally isolated here.
        #
        # Do NOT put touch logic throughout main.py.
        #
        # When the physical interface is connected, this section
        # becomes the only part that needs hardware-specific work.

        self.ready = True

        print("Touchscreen: ready")


    # ========================================================
    # HARDWARE READ
    # ========================================================

    def _read_raw_touch(self):
        """
        Read raw touchscreen coordinates.

        Returns:
            (raw_x, raw_y, pressure)

        or:

            None

        when no finger is detected.

        This is the only method that should directly communicate
        with the physical touchscreen hardware.
        """

        # Hardware-specific implementation goes here.

        return None


    # ========================================================
    # TOUCH DETECTION
    # ========================================================

    def is_pressed(self):
        """
        Return True when the touchscreen is currently pressed.
        """

        if not self.ready or self.closed:
            return False

        point = self._read_raw_touch()

        if point is None:
            return False

        raw_x, raw_y, pressure = point

        return (
            MIN_PRESSURE <= pressure <= MAX_PRESSURE
        )


    def get_touch(self):
        """
        Read and return the current touch.

        Returns:

            {
                "x": screen_x,
                "y": screen_y,
                "pressure": pressure
            }

        or None.
        """

        if not self.ready or self.closed:
            return None

        point = self._read_raw_touch()

        if point is None:
            return None

        raw_x, raw_y, pressure = point

        if pressure < MIN_PRESSURE:
            return None

        if pressure > MAX_PRESSURE:
            return None

        x, y = self.map_to_screen(raw_x, raw_y)

        result = {
            "x": x,
            "y": y,
            "pressure": pressure,
        }

        self.last_position = result
        self.last_touch_time = time.monotonic()

        return result


    def get_position(self):
        """
        Return only (x, y).

        Returns:
            (x, y)

        or None.
        """

        touch = self.get_touch()

        if touch is None:
            return None

        return touch["x"], touch["y"]


    # ========================================================
    # WAITING
    # ========================================================

    def wait_for_touch(self, timeout=None):
        """
        Wait until the user touches the screen.

        timeout:
            None = wait forever
            seconds = stop waiting after that time

        Returns:
            touch dictionary

        or None on timeout.
        """

        start = time.monotonic()

        while not self.closed:

            touch = self.get_touch()

            if touch is not None:
                return touch

            if timeout is not None:
                if time.monotonic() - start >= timeout:
                    return None

            time.sleep(0.01)

        return None


    # ========================================================
    # CALIBRATION
    # ========================================================

    def set_calibration(
        self,
        min_x,
        max_x,
        min_y,
        max_y,
    ):
        """
        Set touchscreen calibration values.
        """

        if min_x >= max_x:
            raise ValueError("min_x must be smaller than max_x")

        if min_y >= max_y:
            raise ValueError("min_y must be smaller than max_y")

        self.ts_min_x = min_x
        self.ts_max_x = max_x
        self.ts_min_y = min_y
        self.ts_max_y = max_y


    def get_calibration(self):
        """
        Return the current calibration values.
        """

        return {
            "min_x": self.ts_min_x,
            "max_x": self.ts_max_x,
            "min_y": self.ts_min_y,
            "max_y": self.ts_max_y,
        }


    def calibrate(self):
        """
        Calibration procedure placeholder.

        The final calibration UI can display four targets:

            ● top-left
            ● top-right
            ● bottom-left
            ● bottom-right

        and collect raw touch values.

        This function is intentionally not pretending to perform
        calibration until the actual Pi hardware reader exists.
        """

        raise NotImplementedError(
            "Hardware calibration must be connected to the "
            "TF028 touch reader first."
        )


    # ========================================================
    # COORDINATE MAPPING
    # ========================================================

    def map_to_screen(self, raw_x, raw_y):
        """
        Convert raw touchscreen coordinates to screen coordinates.
        """

        x_range = self.ts_max_x - self.ts_min_x
        y_range = self.ts_max_y - self.ts_min_y

        if x_range <= 0 or y_range <= 0:
            return 0, 0

        x = (
            (raw_x - self.ts_min_x)
            * self.screen_width
            / x_range
        )

        y = (
            (raw_y - self.ts_min_y)
            * self.screen_height
            / y_range
        )

        x = int(max(0, min(self.screen_width - 1, x)))
        y = int(max(0, min(self.screen_height - 1, y)))

        return x, y


    # ========================================================
    # ROTATION
    # ========================================================

    def set_rotation(self, rotation):
        """
        Set screen rotation.

        Supported:
            0
            1
            2
            3
        """

        if rotation not in (0, 1, 2, 3):
            raise ValueError("Rotation must be 0, 1, 2, or 3")

        self.rotation = rotation


    def rotate_position(self, x, y):
        """
        Convert coordinates according to screen rotation.
        """

        if self.rotation == 0:
            return x, y

        if self.rotation == 1:
            return (
                self.screen_height - 1 - y,
                x,
            )

        if self.rotation == 2:
            return (
                self.screen_width - 1 - x,
                self.screen_height - 1 - y,
            )

        if self.rotation == 3:
            return (
                y,
                self.screen_width - 1 - x,
            )

        return x, y


    # ========================================================
    # UI HELPERS
    # ========================================================

    def is_inside(
        self,
        x,
        y,
        left,
        top,
        right,
        bottom,
    ):
        """
        Check whether a point is inside a rectangular UI area.
        """

        return (
            left <= x <= right
            and
            top <= y <= bottom
        )


    def is_inside_button(self, touch, button):
        """
        Check whether a touch is inside a button dictionary.

        Example:

            button = {
                "x": 20,
                "y": 100,
                "width": 120,
                "height": 50
            }
        """

        if touch is None:
            return False

        x = touch["x"]
        y = touch["y"]

        left = button["x"]
        top = button["y"]

        right = left + button["width"]
        bottom = top + button["height"]

        return self.is_inside(
            x,
            y,
            left,
            top,
            right,
            bottom,
        )


    # ========================================================
    # STATUS
    # ========================================================

    def is_ready(self):
        return self.ready and not self.closed


    def get_status(self):
        return {
            "ready": self.ready,
            "closed": self.closed,
            "rotation": self.rotation,
            "screen_width": self.screen_width,
            "screen_height": self.screen_height,
            "calibration": self.get_calibration(),
            "last_position": self.last_position,
        }


    # ========================================================
    # SHUTDOWN
    # ========================================================

    def close(self):
        """
        Safely shut down touchscreen hardware.
        """

        if self.closed:
            return

        self.closed = True
        self.ready = False

        # Hardware cleanup goes here.

        print("Touchscreen: closed")


# ============================================================
# STANDALONE TEST
# ============================================================

if __name__ == "__main__":

    print()
    print("==============================")
    print("NOAH TOUCHSCREEN TEST")
    print("==============================")
    print()

    touch = NoahTouch()

    print("Status:")
    print(touch.get_status())
    print()

    print("Waiting for touch...")
    print("Press Ctrl+C to stop.")
    print()

    try:

        while True:

            position = touch.get_touch()

            if position is not None:

                print(
                    "Touch:",
                    f"X={position['x']}",
                    f"Y={position['y']}",
                    f"Pressure={position['pressure']}"
                )

            time.sleep(0.05)

    except KeyboardInterrupt:

        print()
        print("Touch test stopped.")

    finally:

        touch.close()