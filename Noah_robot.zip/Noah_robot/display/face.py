import math
import time
from PIL import Image, ImageDraw


class NoahFace:
    """
    Noah's animated robot face.

    This class creates RGB frames.
    The TFT driver will be responsible for displaying them.
    """

    WIDTH = 320
    HEIGHT = 240

    def __init__(self):
        self.state = "idle"
        self.frame = 0

        # Eye positions
        self.left_eye_x = 105
        self.right_eye_x = 215
        self.eye_y = 105

        self.blink_amount = 0.0

        # Looking direction
        self.look_x = 0
        self.look_y = 0

    # ---------------------------------------------------------
    # STATE
    # ---------------------------------------------------------

    def set_state(self, state):
        """
        Available states:
        idle
        listening
        thinking
        speaking
        happy
        confused
        surprised
        sad
        alert
        error
        """

        valid_states = {
            "idle",
            "listening",
            "thinking",
            "speaking",
            "happy",
            "confused",
            "surprised",
            "sad",
            "alert",
            "error",
        }

        if state in valid_states:
            self.state = state
            self.frame = 0

    # ---------------------------------------------------------
    # BLINK
    # ---------------------------------------------------------

    def blink(self, amount):
        """
        amount:
            0.0 = eyes completely open
            1.0 = eyes completely closed
        """

        self.blink_amount = max(0.0, min(1.0, amount))

    # ---------------------------------------------------------
    # EYE MOVEMENT
    # ---------------------------------------------------------

    def look(self, x, y):
        """
        x:
            -1 = left
             0 = center
             1 = right

        y:
            -1 = up
             0 = center
             1 = down
        """

        self.look_x = max(-1, min(1, x))
        self.look_y = max(-1, min(1, y))

    # ---------------------------------------------------------
    # DRAW EYE
    # ---------------------------------------------------------

    def draw_eye(self, draw, x, y, side):
        state = self.state

        # Base eye size
        eye_width = 70
        eye_height = 75

        # Expression changes
        if state == "surprised":
            eye_width = 78
            eye_height = 88

        elif state == "alert":
            eye_height = 58

        elif state == "sad":
            eye_height = 62

        # Blink
        current_height = int(
            eye_height * (1.0 - self.blink_amount)
        )

        if current_height < 4:
            # Closed eye
            draw.line(
                (x - 28, y, x + 28, y),
                fill="white",
                width=8
            )
            return

        top = y - current_height // 2
        bottom = y + current_height // 2

        # Eye
        draw.rounded_rectangle(
            (
                x - eye_width // 2,
                top,
                x + eye_width // 2,
                bottom
            ),
            radius=25,
            fill="white"
        )

        # Pupil movement
        pupil_x = x + int(self.look_x * 15)
        pupil_y = y + int(self.look_y * 12)

        # Happy eyes
        if state == "happy":
            draw.arc(
                (
                    x - 28,
                    y - 15,
                    x + 28,
                    y + 25
                ),
                200,
                340,
                fill="black",
                width=7
            )
            return

        # Pupil
        draw.ellipse(
            (
                pupil_x - 14,
                pupil_y - 14,
                pupil_x + 14,
                pupil_y + 14
            ),
            fill="black"
        )

        # Confused eyebrow
        if state == "confused":
            if side == "left":
                draw.line(
                    (x - 30, top - 15, x + 20, top - 5),
                    fill="white",
                    width=7
                )
            else:
                draw.line(
                    (x - 20, top - 5, x + 30, top - 15),
                    fill="white",
                    width=7
                )

        # Alert eyebrows
        if state == "alert":
            draw.line(
                (x - 30, top - 15, x + 30, top - 25),
                fill="white",
                width=8
            )

    # ---------------------------------------------------------
    # DRAW MOUTH
    # ---------------------------------------------------------

    def draw_mouth(self, draw):
        state = self.state

        cx = self.WIDTH // 2
        cy = 178

        # Speaking animation
        if state == "speaking":
            mouth_size = 12 + int(
                abs(math.sin(self.frame * 0.45)) * 18
            )

            draw.ellipse(
                (
                    cx - 25,
                    cy - mouth_size,
                    cx + 25,
                    cy + mouth_size
                ),
                fill="white"
            )
            return

        # Happy
        if state == "happy":
            draw.arc(
                (
                    cx - 45,
                    cy - 15,
                    cx + 45,
                    cy + 30
                ),
                10,
                170,
                fill="white",
                width=9
            )
            return

        # Sad
        if state == "sad":
            draw.arc(
                (
                    cx - 40,
                    cy - 5,
                    cx + 40,
                    cy + 40
                ),
                190,
                350,
                fill="white",
                width=8
            )
            return

        # Surprised
        if state == "surprised":
            draw.ellipse(
                (
                    cx - 22,
                    cy - 25,
                    cx + 22,
                    cy + 25
                ),
                outline="white",
                width=7
            )
            return

        # Confused
        if state == "confused":
            draw.line(
                (cx - 35, cy, cx + 5, cy + 8),
                fill="white",
                width=7
            )
            draw.line(
                (cx + 5, cy + 8, cx + 35, cy - 5),
                fill="white",
                width=7
            )
            return

        # Alert
        if state == "alert":
            draw.line(
                (cx - 30, cy, cx + 30, cy),
                fill="white",
                width=8
            )
            return

        # Normal mouth
        draw.line(
            (cx - 30, cy, cx + 30, cy),
            fill="white",
            width=7
        )

    # ---------------------------------------------------------
    # DRAW FACE
    # ---------------------------------------------------------

    def render(self):
        """
        Creates one complete frame.
        """

        image = Image.new(
            "RGB",
            (self.WIDTH, self.HEIGHT),
            "black"
        )

        draw = ImageDraw.Draw(image)

        # ---------------------------------------------
        # Automatic eye movement
        # ---------------------------------------------

        if self.state == "thinking":
            self.look(
                math.sin(self.frame * 0.08),
                -1
            )

        elif self.state == "listening":
            self.look(
                math.sin(self.frame * 0.05) * 0.5,
                0
            )

        elif self.state == "idle":
            self.look(
                math.sin(self.frame * 0.025) * 0.15,
                0
            )

        elif self.state == "speaking":
            self.look(0, 0)

        # ---------------------------------------------
        # Draw eyes
        # ---------------------------------------------

        self.draw_eye(
            draw,
            self.left_eye_x,
            self.eye_y,
            "left"
        )

        self.draw_eye(
            draw,
            self.right_eye_x,
            self.eye_y,
            "right"
        )

        # ---------------------------------------------
        # Mouth
        # ---------------------------------------------

        self.draw_mouth(draw)

        # ---------------------------------------------
        # Frame counter
        # ---------------------------------------------

        self.frame += 1

        return image

    # ---------------------------------------------------------
    # ANIMATION LOOP
    # ---------------------------------------------------------

    def run_animation(self, display_callback, fps=20):
        """
        display_callback(image)

        The callback is supplied by tft.py.
        """

        delay = 1.0 / fps

        while True:
            image = self.render()

            display_callback(image)

            time.sleep(delay)