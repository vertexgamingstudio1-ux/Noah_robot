# display/tft.py

class ILI9338:
    """
    Low-level driver layer for the 2.8" MCUFRIEND TFT.

    Resolution:
        240 x 320

    Controller:
        ILI9338
    """

    WIDTH = 240
    HEIGHT = 320

    def __init__(self):
        self.initialized = False

    def begin(self):
        """Initialize the TFT."""
        print("TFT: starting ILI9338...")

        # Hardware initialization will be added here.
        # This is where GPIO setup and TFT initialization
        # commands will eventually go.

        self.initialized = True
        print("TFT: ready")

    def set_rotation(self, rotation=0):
        """
        Set display rotation.

        rotation:
            0 = portrait
            1 = landscape
            2 = portrait reversed
            3 = landscape reversed
        """
        if rotation not in (0, 1, 2, 3):
            raise ValueError("Rotation must be 0, 1, 2, or 3")

        self.rotation = rotation

    def fill_screen(self, color):
        """Fill the entire TFT with one RGB565 color."""
        if not self.initialized:
            raise RuntimeError("TFT has not been initialized")

        # Hardware drawing code will go here.
        pass

    def draw_pixel(self, x, y, color):
        """Draw one pixel."""
        if not self.initialized:
            raise RuntimeError("TFT has not been initialized")

        if x < 0 or x >= self.WIDTH:
            return

        if y < 0 or y >= self.HEIGHT:
            return

        # Hardware pixel-writing code will go here.
        pass

    def draw_image(self, image):
        """Send a Pillow image to the TFT."""
        if not self.initialized:
            raise RuntimeError("TFT has not been initialized")

        if image is None:
            return

        # Pillow → RGB565 → TFT transfer will go here.
        pass

    def clear(self):
        """Clear the display."""
        self.fill_screen(0x0000)

    def close(self):
        """Release TFT resources."""
        self.initialized = False
        print("TFT: closed")