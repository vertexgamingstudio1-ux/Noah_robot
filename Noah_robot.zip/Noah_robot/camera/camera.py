from picamera2 import Picamera2
import time


class NoahCamera:
    """
    Noah's camera system.

    Handles camera initialization,
    preview, and image capture.
    """

    def __init__(self):
        print("Camera: initializing...")

        self.camera = Picamera2()

        config = self.camera.create_still_configuration()
        self.camera.configure(config)

        self.camera.start()

        time.sleep(2)

        print("Camera: ready")

    def capture(self, filename="noah_capture.jpg"):
        """
        Capture an image and save it.
        """

        print("Camera: capturing...")

        self.camera.capture_file(filename)

        print(f"Camera: image saved -> {filename}")

        return filename

    def start_preview(self):
        """
        Start the camera preview.
        """

        print("Camera: preview started")

        self.camera.start_preview()

    def stop_preview(self):
        """
        Stop the camera preview.
        """

        self.camera.stop_preview()

        print("Camera: preview stopped")

    def close(self):
        """
        Shut down the camera safely.
        """

        self.camera.stop()
        self.camera.close()

        print("Camera: closed")


if __name__ == "__main__":
    print("\nStarting Noah Camera test...\n")

    camera = NoahCamera()

    try:
        camera.capture("noah_test.jpg")

        print("\nCamera test complete.")

    except Exception as error:
        print("\nCamera error:")
        print(error)

    finally:
        camera.close()
