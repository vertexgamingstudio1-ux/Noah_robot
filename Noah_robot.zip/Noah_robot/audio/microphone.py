# microphone/microphone.py

import sounddevice as sd
import numpy as np


class NoahMicrophone:
    """
    Microphone input system for Noah.
    """

    SAMPLE_RATE = 16000
    CHANNELS = 1
    DTYPE = "int16"

    def __init__(self, device=None):
        self.device = device
        self.recording = False

    def list_devices(self):
        """Show available audio devices."""
        print("\nAvailable audio devices:")
        print(sd.query_devices())

    def start(self):
        """Start microphone input."""
        if self.recording:
            return

        self.recording = True
        print("Microphone: listening...")

    def stop(self):
        """Stop microphone input."""
        self.recording = False
        print("Microphone: stopped")

    def record(self, duration=3):
        """
        Record audio for the specified number of seconds.

        Returns:
            numpy array containing the recorded audio.
        """

        print(f"Recording for {duration} seconds...")

        audio = sd.rec(
            int(duration * self.SAMPLE_RATE),
            samplerate=self.SAMPLE_RATE,
            channels=self.CHANNELS,
            dtype=self.DTYPE,
            device=self.device
        )

        sd.wait()

        print("Recording complete.")

        return audio

    def volume(self, audio):
        """Return approximate audio volume."""
        if audio is None or len(audio) == 0:
            return 0.0

        samples = audio.astype(np.float32)

        return float(np.sqrt(np.mean(samples ** 2)))

    def close(self):
        """Close microphone system."""
        self.recording = False
        print("Microphone: closed")


if __name__ == "__main__":
    mic = NoahMicrophone()

    mic.list_devices()

    audio = mic.record(3)

    print("Audio samples:", len(audio))
    print("Volume:", mic.volume(audio))

    mic.close()