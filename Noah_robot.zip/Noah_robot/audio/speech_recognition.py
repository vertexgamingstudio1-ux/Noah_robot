import json
import os
import re

import sounddevice as sd
from vosk import Model, KaldiRecognizer


class NoahSpeechRecognizer:
    """
    Noah multilingual offline speech recognition.

    Languages:
        English
        Hindi
        Gujarati
        Japanese
        Chinese

    Optimization:
        - Remembers the last successful language.
        - Tries the previous language first.
        - Loads only one Vosk model at a time.
        - Falls back to other languages only when necessary.
    """

    LANGUAGE_MODELS = {
        "english":
            "models/en-us/vosk-model-small-en-us-0.15/"
            "vosk-model-small-en-us-0.15",

        "hindi":
            "models/hindi/vosk-model-small-hi-0.22/"
            "vosk-model-small-hi-0.22",

        "gujarati":
            "models/gujarati/vosk-model-gu-0.42/"
            "vosk-model-gu-0.42",

        "japanese":
            "models/japanese/vosk-model-small-ja-0.22/"
            "vosk-model-small-ja-0.22",

        "chinese":
            "models/chinese/vosk-model-small-cn-0.22/"
            "vosk-model-small-cn-0.22",
    }

    LANGUAGE_ALIASES = {
        "en": "english",
        "english": "english",

        "hi": "hindi",
        "hindi": "hindi",

        "gu": "gujarati",
        "gujarati": "gujarati",

        "ja": "japanese",
        "japanese": "japanese",

        "zh": "chinese",
        "chinese": "chinese",
    }

    SAMPLE_RATE = 16000
    CHANNELS = 1

    def __init__(self):

        self.current_language = None
        self.current_model = None
        self.current_recognizer = None

        self.available_languages = []

        self._check_models()

        print()
        print(
            "Speech recognition initialized."
        )

        print(
            "Available languages:",
            ", ".join(self.available_languages)
        )

    # ==================================================
    # CHECK MODELS
    # ==================================================

    def _check_models(self):

        self.available_languages = []

        for language, path in self.LANGUAGE_MODELS.items():

            if os.path.isdir(path):

                self.available_languages.append(
                    language
                )

            else:

                print(
                    f"Speech model missing: "
                    f"{language}"
                )

        if not self.available_languages:

            raise FileNotFoundError(
                "No Vosk speech recognition models found."
            )

    # ==================================================
    # LOAD MODEL
    # ==================================================

    def _load_model(self, language):

        if language not in self.LANGUAGE_MODELS:

            raise ValueError(
                f"Unsupported language: {language}"
            )

        if language not in self.available_languages:

            raise FileNotFoundError(
                f"Model for {language} is not available."
            )

        # Already loaded.
        if (
            self.current_language == language
            and self.current_model is not None
        ):

            return True

        # Remove previous model.
        self._unload_model()

        path = self.LANGUAGE_MODELS[language]

        print(
            f"Loading speech model: {language}"
        )

        self.current_model = Model(path)

        self.current_recognizer = (
            KaldiRecognizer(
                self.current_model,
                self.SAMPLE_RATE
            )
        )

        self.current_language = language

        return True

    # ==================================================
    # UNLOAD MODEL
    # ==================================================

    def _unload_model(self):

        self.current_recognizer = None
        self.current_model = None

    # ==================================================
    # RECORD AUDIO
    # ==================================================

    def _record_audio(self, duration=5):

        print()
        print(
            f"Listening for {duration} seconds..."
        )

        try:

            audio = sd.rec(
                int(
                    duration *
                    self.SAMPLE_RATE
                ),
                samplerate=self.SAMPLE_RATE,
                channels=self.CHANNELS,
                dtype="int16"
            )

            sd.wait()

            print(
                "Recording complete."
            )

            return audio.tobytes()

        except Exception as error:

            print(
                f"Microphone recording error: "
                f"{error}"
            )

            return None

    # ==================================================
    # RECOGNIZE WITH CURRENT MODEL
    # ==================================================

    def _recognize_audio(self, audio_bytes):

        if not audio_bytes:
            return ""

        if self.current_recognizer is None:
            return ""

        try:

            self.current_recognizer.Reset()

        except Exception:
            pass

        try:

            self.current_recognizer.AcceptWaveform(
                audio_bytes
            )

            result = (
                self.current_recognizer
                .FinalResult()
            )

            data = json.loads(result)

            text = data.get(
                "text",
                ""
            ).strip()

            return text

        except Exception as error:

            print(
                f"Recognition error: {error}"
            )

            return ""

    # ==================================================
    # SCRIPT DETECTION
    # ==================================================

    def _detect_language_from_text(
        self,
        text
    ):

        if not text:
            return None

        # Gujarati
        if re.search(
            r"[\u0A80-\u0AFF]",
            text
        ):

            return "gujarati"

        # Hindi / Devanagari
        if re.search(
            r"[\u0900-\u097F]",
            text
        ):

            return "hindi"

        # Japanese
        if re.search(
            r"[\u3040-\u309F\u30A0-\u30FF]",
            text
        ):

            return "japanese"

        # Chinese
        if re.search(
            r"[\u4E00-\u9FFF]",
            text
        ):

            return "chinese"

        # English / Latin
        if re.search(
            r"[A-Za-z]",
            text
        ):

            return "english"

        return None

    # ==================================================
    # SCORE RESULT
    # ==================================================

    def _score_result(
        self,
        text,
        language
    ):

        if not text:
            return 0

        score = 0

        # More words generally means a more useful result.
        words = text.split()

        score += min(
            len(words) * 2,
            20
        )

        detected_language = (
            self._detect_language_from_text(
                text
            )
        )

        # Strong bonus when detected script
        # matches the model being tested.
        if detected_language == language:

            score += 50

        # Penalize extremely short results.
        if len(text) <= 1:

            score -= 10

        return score

    # ==================================================
    # LANGUAGE ORDER
    # ==================================================

    def _get_language_order(self):

        languages = list(
            self.available_languages
        )

        # Previous language gets priority.
        if (
            self.current_language
            and self.current_language in languages
        ):

            languages.remove(
                self.current_language
            )

            languages.insert(
                0,
                self.current_language
            )

        return languages

    # ==================================================
    # AUTOMATIC RECOGNITION
    # ==================================================

    def recognize_auto(self, duration=5):

        audio_bytes = self._record_audio(
            duration
        )

        if not audio_bytes:

            return "", None

        language_order = (
            self._get_language_order()
        )

        best_text = ""
        best_language = None
        best_score = 0

        print()
        print(
            "Trying languages:",
            ", ".join(language_order)
        )

        # ----------------------------------------------
        # FAST PATH
        #
        # Try the previous language first.
        # ----------------------------------------------

        if language_order:

            first_language = (
                language_order[0]
            )

            try:

                self._load_model(
                    first_language
                )

                text = (
                    self._recognize_audio(
                        audio_bytes
                    )
                )

                score = (
                    self._score_result(
                        text,
                        first_language
                    )
                )

                if text:

                    print(
                        f"{first_language}: "
                        f"{text}"
                    )

                # Strong result → use it immediately.
                if (
                    text
                    and score >= 50
                ):

                    print(
                        f"Detected language: "
                        f"{first_language}"
                    )

                    return (
                        text,
                        first_language
                    )

                if score > best_score:

                    best_score = score
                    best_text = text
                    best_language = (
                        first_language
                    )

            except Exception as error:

                print(
                    f"{first_language} "
                    f"recognition failed: "
                    f"{error}"
                )

        # ----------------------------------------------
        # FALLBACK
        #
        # Only try other languages if the fast path
        # was not strong enough.
        # ----------------------------------------------

        for language in language_order[1:]:

            try:

                self._load_model(
                    language
                )

                text = (
                    self._recognize_audio(
                        audio_bytes
                    )
                )

                score = (
                    self._score_result(
                        text,
                        language
                    )
                )

                if text:

                    print(
                        f"{language}: "
                        f"{text}"
                    )

                if score > best_score:

                    best_score = score
                    best_text = text
                    best_language = language

                # Script-based match is strong enough.
                if (
                    text
                    and self._detect_language_from_text(
                        text
                    ) == language
                ):

                    print()
                    print(
                        f"Detected language: "
                        f"{language}"
                    )

                    return (
                        text,
                        language
                    )

            except Exception as error:

                print(
                    f"{language} "
                    f"recognition failed: "
                    f"{error}"
                )

        # ----------------------------------------------
        # FINAL RESULT
        # ----------------------------------------------

        if best_text:

            self.current_language = (
                best_language
            )

            print()
            print(
                f"Best result: "
                f"{best_language}"
            )

            return (
                best_text,
                best_language
            )

        print(
            "No speech recognized."
        )

        return "", None

    # ==================================================
    # MANUAL LANGUAGE
    # ==================================================

    def set_language(self, language):

        language = (
            language
            .lower()
            .strip()
        )

        language = (
            self.LANGUAGE_ALIASES.get(
                language,
                language
            )
        )

        if language not in self.LANGUAGE_MODELS:

            raise ValueError(
                f"Unsupported language: "
                f"{language}"
            )

        if language not in self.available_languages:

            raise FileNotFoundError(
                f"Model unavailable: "
                f"{language}"
            )

        self._load_model(
            language
        )

        print(
            f"Speech language set to: "
            f"{language}"
        )

    # ==================================================
    # GET CURRENT LANGUAGE
    # ==================================================

    def get_language(self):

        return self.current_language

    # ==================================================
    # GET SUPPORTED LANGUAGES
    # ==================================================

    def get_supported_languages(self):

        return list(
            self.available_languages
        )

    # ==================================================
    # RESET
    # ==================================================

    def reset(self):

        self._unload_model()

        self.current_language = None

        print(
            "Speech recognizer reset."
        )

    # ==================================================
    # CLOSE
    # ==================================================

    def close(self):

        self._unload_model()

        print(
            "Speech recognition: closed."
        )


# ======================================================
# TEST
# ======================================================

if __name__ == "__main__":

    print()
    print("==============================")
    print("NOAH SPEECH RECOGNITION TEST")
    print("==============================")

    recognizer = None

    try:

        recognizer = (
            NoahSpeechRecognizer()
        )

        print()
        print(
            "Speak something..."
        )

        text, language = (
            recognizer.recognize_auto(
                duration=5
            )
        )

        print()
        print("------------------------------")
        print(
            "Recognized text:",
            text
        )
        print(
            "Detected language:",
            language
        )
        print("------------------------------")

    except Exception as error:

        print()
        print(
            "Test error:",
            error
        )

    finally:

        if recognizer:

            recognizer.close()
