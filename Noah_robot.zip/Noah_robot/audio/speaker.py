import pyttsx3


class NoahSpeaker:
    """
    Noah's Text-to-Speech speaker system.

    Converts text into speech using the local system
    speech engine.
    """

    DEFAULT_RATE = 150
    DEFAULT_VOLUME = 1.0

    def __init__(self, rate=DEFAULT_RATE, volume=DEFAULT_VOLUME, voice_index=None):
        self.engine = None
        self.rate = rate
        self.volume = volume
        self.voice_index = voice_index
        self.speaking = False

        self._initialize()

    def _initialize(self):
        """Initialize the text-to-speech engine."""
        print("Speaker: initializing...")

        try:
            self.engine = pyttsx3.init()

            self.engine.setProperty("rate", self.rate)
            self.engine.setProperty("volume", self.volume)

            if self.voice_index is not None:
                voices = self.engine.getProperty("voices")

                if 0 <= self.voice_index < len(voices):
                    self.engine.setProperty(
                        "voice",
                        voices[self.voice_index].id
                    )

            self.engine.connect(
                "started-utterance",
                self._on_start
            )

            self.engine.connect(
                "finished-utterance",
                self._on_finished
            )

            print("Speaker: ready")

        except Exception as error:
            print("Speaker initialization failed:")
            print(error)
            self.engine = None

    def _on_start(self, name):
        """Called when Noah starts speaking."""
        self.speaking = True
        print("Noah: speaking...")

    def _on_finished(self, name, completed):
        """Called when Noah finishes speaking."""
        self.speaking = False
        print("Noah: finished speaking.")

    def speak(self, text):
        """
        Speak the supplied text.

        Returns True if speech was successfully started,
        otherwise False.
        """

        if self.engine is None:
            print("Speaker: engine is not available.")
            return False

        if text is None:
            return False

        text = str(text).strip()

        if not text:
            return False

        try:
            self.engine.say(text)
            self.engine.runAndWait()
            return True

        except Exception as error:
            self.speaking = False
            print("Speaker error:")
            print(error)
            return False

    def stop(self):
        """Immediately stop current speech."""
        if self.engine is None:
            return

        try:
            self.engine.stop()
        except Exception as error:
            print("Speaker stop error:")
            print(error)

        self.speaking = False

    def set_rate(self, rate):
        """Change speaking speed."""
        if self.engine is None:
            return

        if rate <= 0:
            raise ValueError("Speech rate must be greater than 0.")

        self.rate = rate
        self.engine.setProperty("rate", rate)

    def set_volume(self, volume):
        """Change speaker volume from 0.0 to 1.0."""
        if self.engine is None:
            return

        if not 0.0 <= volume <= 1.0:
            raise ValueError("Volume must be between 0.0 and 1.0.")

        self.volume = volume
        self.engine.setProperty("volume", volume)

    def list_voices(self):
        """Display all voices available on the system."""
        if self.engine is None:
            print("Speaker: engine is not available.")
            return

        voices = self.engine.getProperty("voices")

        print("\nAvailable voices:")

        for index, voice in enumerate(voices):
            print(f"\nVoice {index}")
            print(f"Name: {voice.name}")
            print(f"ID: {voice.id}")

            if hasattr(voice, "languages"):
                print(f"Languages: {voice.languages}")

    def set_voice(self, voice_index):
        """Select a voice by its system index."""
        if self.engine is None:
            return False

        voices = self.engine.getProperty("voices")

        if not 0 <= voice_index < len(voices):
            print("Speaker: invalid voice index.")
            return False

        self.engine.setProperty(
            "voice",
            voices[voice_index].id
        )

        self.voice_index = voice_index

        print(f"Speaker: voice changed to {voice_index}")
        return True

    def is_speaking(self):
        """Return True while Noah is speaking."""
        return self.speaking

    def close(self):
        """Safely shut down the speaker."""
        if self.engine is None:
            return

        try:
            self.engine.stop()
        except Exception:
            pass

        self.speaking = False
        self.engine = None

        print("Speaker: closed")


# ---------------------------------------------------------
# TEST
# ---------------------------------------------------------

if __name__ == "__main__":

    speaker = NoahSpeaker()

    print("\nTesting Noah speaker...")

    speaker.speak(
        "Hello. I am Noah. My speaker system is working."
    )

    print("\nSpeaker test complete.")

    speaker.close()