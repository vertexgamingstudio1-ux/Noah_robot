"""
Noah Robot - Motor Controller

Responsibility:
    Control the two DC motors through an L298N motor driver.

main.py is responsible for deciding WHEN Noah should move.
This file is responsible only for HOW the motors move.
"""

import time

try:
    from gpiozero import OutputDevice, PWMOutputDevice
    GPIOZERO_AVAILABLE = True
except ImportError:
    GPIOZERO_AVAILABLE = False


class NoahMotors:
    """
    Two-motor differential drive controller.

    L298N:
        Left motor  -> IN1, IN2, ENA
        Right motor -> IN3, IN4, ENB
    """

    # ==========================================================
    # PUT YOUR ACTUAL GPIO NUMBERS HERE
    # These are BCM GPIO numbers, NOT physical pin numbers.
    # ==========================================================

    LEFT_IN1 = None
    LEFT_IN2 = None
    LEFT_EN = None

    RIGHT_IN1 = None
    RIGHT_IN2 = None
    RIGHT_EN = None

    DEFAULT_SPEED = 0.6

    def __init__(self):
        self.initialized = False
        self.current_action = "stopped"
        self.current_speed = 0.0

        self.left_in1 = None
        self.left_in2 = None
        self.left_en = None

        self.right_in1 = None
        self.right_in2 = None
        self.right_en = None

        self._check_configuration()

        if not GPIOZERO_AVAILABLE:
            raise RuntimeError(
                "gpiozero is not installed. "
                "Install it on the Raspberry Pi."
            )

        print("Motors: initializing...")

        self.left_in1 = OutputDevice(self.LEFT_IN1)
        self.left_in2 = OutputDevice(self.LEFT_IN2)
        self.left_en = PWMOutputDevice(self.LEFT_EN)

        self.right_in1 = OutputDevice(self.RIGHT_IN1)
        self.right_in2 = OutputDevice(self.RIGHT_IN2)
        self.right_en = PWMOutputDevice(self.RIGHT_EN)

        self.stop()

        self.initialized = True

        print("Motors: ready")

    # ----------------------------------------------------------
    # Configuration
    # ----------------------------------------------------------

    def _check_configuration(self):
        pins = {
            "LEFT_IN1": self.LEFT_IN1,
            "LEFT_IN2": self.LEFT_IN2,
            "LEFT_EN": self.LEFT_EN,
            "RIGHT_IN1": self.RIGHT_IN1,
            "RIGHT_IN2": self.RIGHT_IN2,
            "RIGHT_EN": self.RIGHT_EN,
        }

        missing = [
            name for name, value in pins.items()
            if value is None
        ]

        if missing:
            raise ValueError(
                "Motor GPIO pins are not configured.\n"
                "Set these values in hardware/motors.py:\n"
                + ", ".join(missing)
            )

    # ----------------------------------------------------------
    # Internal motor control
    # ----------------------------------------------------------

    def _set_left_motor(self, direction, speed):
        speed = max(0.0, min(1.0, speed))

        if direction == "forward":
            self.left_in1.on()
            self.left_in2.off()

        elif direction == "backward":
            self.left_in1.off()
            self.left_in2.on()

        else:
            self.left_in1.off()
            self.left_in2.off()
            speed = 0.0

        self.left_en.value = speed

    def _set_right_motor(self, direction, speed):
        speed = max(0.0, min(1.0, speed))

        if direction == "forward":
            self.right_in1.on()
            self.right_in2.off()

        elif direction == "backward":
            self.right_in1.off()
            self.right_in2.on()

        else:
            self.right_in1.off()
            self.right_in2.off()
            speed = 0.0

        self.right_en.value = speed

    # ----------------------------------------------------------
    # Public movement commands
    # ----------------------------------------------------------

    def forward(self, speed=None):
        speed = self.DEFAULT_SPEED if speed is None else speed

        self._set_left_motor("forward", speed)
        self._set_right_motor("forward", speed)

        self.current_action = "forward"
        self.current_speed = speed

        print(f"Motors: forward ({speed:.2f})")

    def backward(self, speed=None):
        speed = self.DEFAULT_SPEED if speed is None else speed

        self._set_left_motor("backward", speed)
        self._set_right_motor("backward", speed)

        self.current_action = "backward"
        self.current_speed = speed

        print(f"Motors: backward ({speed:.2f})")

    def left(self, speed=None):
        speed = self.DEFAULT_SPEED if speed is None else speed

        # Tank-style turning:
        # left motor backward
        # right motor forward
        self._set_left_motor("backward", speed)
        self._set_right_motor("forward", speed)

        self.current_action = "left"
        self.current_speed = speed

        print(f"Motors: left ({speed:.2f})")

    def right(self, speed=None):
        speed = self.DEFAULT_SPEED if speed is None else speed

        # right motor backward
        # left motor forward
        self._set_left_motor("forward", speed)
        self._set_right_motor("backward", speed)

        self.current_action = "right"
        self.current_speed = speed

        print(f"Motors: right ({speed:.2f})")

    def stop(self):
        if self.left_in1 is not None:
            self.left_in1.off()
            self.left_in2.off()
            self.left_en.value = 0

        if self.right_in1 is not None:
            self.right_in1.off()
            self.right_in2.off()
            self.right_en.value = 0

        self.current_action = "stopped"
        self.current_speed = 0.0

        print("Motors: stopped")

    # ----------------------------------------------------------
    # Timed movement
    # ----------------------------------------------------------

    def move_for(self, direction, duration, speed=None):
        """
        Move for a specific amount of time and then stop.

        Example:
            motors.move_for("forward", 2)
        """

        if duration <= 0:
            self.stop()
            return

        commands = {
            "forward": self.forward,
            "backward": self.backward,
            "left": self.left,
            "right": self.right,
        }

        if direction not in commands:
            raise ValueError(
                f"Unknown movement direction: {direction}"
            )

        commands[direction](speed)

        try:
            time.sleep(duration)
        finally:
            self.stop()

    # ----------------------------------------------------------
    # Status
    # ----------------------------------------------------------

    def get_status(self):
        return {
            "initialized": self.initialized,
            "action": self.current_action,
            "speed": self.current_speed,
        }

    # ----------------------------------------------------------
    # Cleanup
    # ----------------------------------------------------------

    def close(self):
        self.stop()

        devices = [
            self.left_in1,
            self.left_in2,
            self.left_en,
            self.right_in1,
            self.right_in2,
            self.right_en,
        ]

        for device in devices:
            if device is not None:
                device.close()

        self.initialized = False

        print("Motors: closed")


# ==============================================================
# Standalone test
# ==============================================================

if __name__ == "__main__":
    print("\n==============================")
    print("      NOAH MOTOR TEST")
    print("==============================\n")

    motors = None

    try:
        motors = NoahMotors()

        print("\nMotor status:")
        print(motors.get_status())

        print("\nTesting forward...")
        motors.move_for("forward", 1)

        print("\nTesting backward...")
        motors.move_for("backward", 1)

        print("\nTesting left...")
        motors.move_for("left", 1)

        print("\nTesting right...")
        motors.move_for("right", 1)

        print("\nMotor test complete.")

    except KeyboardInterrupt:
        print("\nMotor test interrupted.")

    except Exception as error:
        print("\nMotor error:")
        print(error)

    finally:
        if motors is not None:
            motors.close()